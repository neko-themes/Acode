## Neko Dracula 🧛🏻‍♂️

<img src="./icon.png">

Neko Dracula is an elegant theme with strong colors originally written for vscode and soon after was ported to acode, neko dracula was written to have strong colors but it is a strong color that does not tire the eyes, perfect for the dev to spend hours followed by programming.